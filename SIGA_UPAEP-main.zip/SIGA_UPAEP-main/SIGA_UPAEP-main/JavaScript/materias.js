document.addEventListener("DOMContentLoaded", () => {
    const materiasTable = document.getElementById("materiasTable");
    const searchMateria = document.querySelector(".search-container input");
    const recordsInfo = document.querySelector(".pagination-info p");
    const searchContainer = searchMateria.parentElement;

    let notFoundMessage = document.createElement("p");
    notFoundMessage.classList.add("not-found-message");
    notFoundMessage.textContent = "Materia no encontrada";
    searchContainer.appendChild(notFoundMessage);

    let allMaterias = [
        { clave: "MAT111", modulo: 1, asignatura: "Cálculo Diferencial", prerrequisitos: "MAT110", equivalencias: "MIN012", plan: "01", estado: "No ofertada" },
        { clave: "TCD007", modulo: 3, asignatura: "Base de Datos", prerrequisitos: "TCD003", equivalencias: "LT1005", plan: "01", estado: "No ofertada" },
        { clave: "ISW226", modulo: 4, asignatura: "Ingeniería de Usabilidad", prerrequisitos: "TCD004", equivalencias: "ISW210", plan: "01", estado: "Ofertada" }
    ];

    function renderTable(filteredMaterias) {
        materiasTable.innerHTML = "";

        if (filteredMaterias.length === 0) {
            notFoundMessage.classList.add("show");
            recordsInfo.textContent = `Mostrando 0 de ${allMaterias.length} registros`;
        } else {
            notFoundMessage.classList.remove("show");
            filteredMaterias.forEach(materia => {
                let row = `<tr>
                    <td>${materia.clave}</td>
                    <td>${materia.modulo}</td>
                    <td>${materia.asignatura}</td>
                    <td><span class="editable" data-field="prerrequisitos">${materia.prerrequisitos}</span></td>
                    <td><span class="editable" data-field="equivalencias">${materia.equivalencias}</span></td>
                    <td>${materia.plan}</td>
                    <td class="estado ${materia.estado === 'Ofertada' ? 'ofertada' : 'no-ofertada'}">${materia.estado}</td>
                    <td>
                        <img src="Imagenes/editar.svg" class="edit-icon" data-clave="${materia.clave}">
                    </td>
                </tr>`;
                materiasTable.innerHTML += row;
            });
            recordsInfo.textContent = `Mostrando ${filteredMaterias.length} de ${allMaterias.length} registros`;
        }
        addEditListeners();
    }

    function addEditListeners() {
        const editIcons = document.querySelectorAll(".edit-icon");
        editIcons.forEach(icon => {
            icon.addEventListener("click", function() {
                const clave = this.getAttribute("data-clave");
                const row = this.closest("tr");
                const prerrequisitos = row.querySelector("[data-field='prerrequisitos']");
                const equivalencias = row.querySelector("[data-field='equivalencias']");

                // Guardar el ancho original de las celdas
                const prerrequisitosWidth = prerrequisitos.offsetWidth;
                const equivalenciasWidth = equivalencias.offsetWidth;

                // Convertir el contenido en campos de entrada
                prerrequisitos.innerHTML = `<input type="text" value="${prerrequisitos.textContent}" style="width: ${prerrequisitosWidth}px;">`;
                equivalencias.innerHTML = `<input type="text" value="${equivalencias.textContent}" style="width: ${equivalenciasWidth}px;">`;

                // Ocultar el ícono de editar y mostrar el ícono de palomita (guardar)
                this.style.display = "none";

                // Crear el ícono de palomita (guardar)
                const saveIcon = document.createElement("span");
                saveIcon.textContent = "✓"; // Emoji de palomita
                saveIcon.classList.add("save-icon");
                saveIcon.style.display = "inline-block";

                // Insertar el ícono de palomita junto al ícono de editar
                this.parentNode.insertBefore(saveIcon, this.nextSibling);

                // Guardar los cambios al hacer clic en el ícono de palomita
                saveIcon.addEventListener("click", function() {
                    const newPrerrequisitos = prerrequisitos.querySelector("input").value;
                    const newEquivalencias = equivalencias.querySelector("input").value;

                    const materiaIndex = allMaterias.findIndex(m => m.clave === clave);
                    allMaterias[materiaIndex].prerrequisitos = newPrerrequisitos;
                    allMaterias[materiaIndex].equivalencias = newEquivalencias;

                    renderTable(allMaterias);
                }, { once: true });
            });
        });
    }

    searchMateria.addEventListener("input", function () {
        let searchTerm = searchMateria.value.toLowerCase();
        let filtered = allMaterias.filter(materia => 
            materia.clave.toLowerCase().includes(searchTerm) ||
            materia.asignatura.toLowerCase().includes(searchTerm) ||
            materia.equivalencias.toLowerCase().includes(searchTerm) ||
            materia.plan.toLowerCase().includes(searchTerm)
        );
        renderTable(filtered);
    });

    renderTable(allMaterias);
    const deletePlanButton = document.querySelector(".table-actions .btn:nth-child(2)"); // Botón "Eliminar Plan"
    const deletePlanModal = document.getElementById("deletePlanModal");
    const confirmModal = document.getElementById("confirmModal");
    const planList = document.getElementById("planList");
    const closeModalButtons = document.querySelectorAll(".close");
    const confirmDeleteButton = document.getElementById("confirmDelete");
    const cancelDeleteButton = document.getElementById("cancelDelete");

    // Lista de planes (puedes obtenerla dinámicamente desde una API o base de datos)
    let planes = ["Plan 01", "Plan 02", "Plan 03"];
    let selectedPlan = null;

    // Mostrar el modal de eliminar plan
    deletePlanButton.addEventListener("click", () => {
        // Limpiar la lista de planes
        planList.innerHTML = "";

        // Llenar la lista de planes
        planes.forEach(plan => {
            const li = document.createElement("li");
            li.textContent = plan;
            li.addEventListener("click", () => {
                selectedPlan = plan;
                deletePlanModal.style.display = "none";
                confirmModal.style.display = "flex";
            });
            planList.appendChild(li);
        });

        // Mostrar el modal
        deletePlanModal.style.display = "flex";
    });

    // Cerrar modales
    closeModalButtons.forEach(button => {
        button.addEventListener("click", () => {
            deletePlanModal.style.display = "none";
            confirmModal.style.display = "none";
        });
    });

    // Confirmar eliminación
    confirmDeleteButton.addEventListener("click", () => {
        if (selectedPlan) {
            // Eliminar el plan seleccionado
            planes = planes.filter(plan => plan !== selectedPlan);
            alert(`Plan "${selectedPlan}" eliminado correctamente.`);
            selectedPlan = null;
        }
        confirmModal.style.display = "none";
    });

    // Cancelar eliminación
    cancelDeleteButton.addEventListener("click", () => {
        selectedPlan = null;
        confirmModal.style.display = "none";
    });

    // Cerrar modales al hacer clic fuera de ellos
    window.addEventListener("click", (event) => {
        if (event.target === deletePlanModal) {
            deletePlanModal.style.display = "none";
        }
        if (event.target === confirmModal) {
            confirmModal.style.display = "none";
        }
    });
    const addPlanButton = document.querySelector(".table-actions .btn:nth-child(1)"); // Botón "Agregar Plan"
    const addPlanModal = document.getElementById("addPlanModal");
    const excelFileInput = document.getElementById("excelFileInput");
    const uploadFileButton = document.getElementById("uploadFile");
    const fileStatus = document.getElementById("fileStatus");

    // Mostrar el modal de agregar plan
    addPlanButton.addEventListener("click", () => {
        addPlanModal.style.display = "flex";
    });

    // Cerrar modales
    closeModalButtons.forEach(button => {
        button.addEventListener("click", () => {
            addPlanModal.style.display = "none";
        });
    });

    // Cargar archivo Excel
    uploadFileButton.addEventListener("click", () => {
        const file = excelFileInput.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function (e) {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, { type: "array" });

                // Procesar la primera hoja del archivo
                const sheetName = workbook.SheetNames[0];
                const sheet = workbook.Sheets[sheetName];
                const jsonData = XLSX.utils.sheet_to_json(sheet);

                // Aquí puedes procesar los datos del archivo Excel
                fileStatus.textContent = `Archivo cargado: ${file.name}`;
                console.log("Datos del archivo:", jsonData);

                // Agregar los planes a la lista (ejemplo)
                jsonData.forEach(row => {
                    // Aquí puedes agregar los planes a tu lista
                    console.log("Plan:", row);
                });

                // Cerrar el modal después de cargar el archivo
                addPlanModal.style.display = "none";
            };
            reader.readAsArrayBuffer(file);
        } else {
            fileStatus.textContent = "Por favor, selecciona un archivo.";
        }
    });

    // Cerrar modales al hacer clic fuera de ellos
    window.addEventListener("click", (event) => {
        if (event.target === addPlanModal) {
            addPlanModal.style.display = "none";
        }
    });
});
